Loose Leaf
===

Loose Leaf is a WordPress portfolio theme. An optional custom header image provides the background for the large call-to-action section on the front page. Jetpack’s Custom Content Types are supported, allowing you to create a masonry portfolio grid, as well as a testimonial page.
