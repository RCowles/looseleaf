<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Loose Leaf
 */
?>


	<div id="frontpage-widgets" class="wrapper">
		<?php dynamic_sidebar( 'frontpage-widgets' ); ?>
	</div><!-- #frontpage-widgets !-->